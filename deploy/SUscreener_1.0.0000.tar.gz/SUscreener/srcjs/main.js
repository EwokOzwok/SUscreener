import './sw-register.js';
import './sw-register.js';
